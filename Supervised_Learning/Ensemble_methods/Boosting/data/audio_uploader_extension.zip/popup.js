
let mediaRecorder;
let audioChunks = [];

document.getElementById('startBtn').onclick = async () => {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  mediaRecorder = new MediaRecorder(stream);
  audioChunks = [];

  mediaRecorder.ondataavailable = event => {
    audioChunks.push(event.data);
  };

  mediaRecorder.onstop = () => {
    const blob = new Blob(audioChunks, { type: 'audio/webm' });
    const url = URL.createObjectURL(blob);

    const audio = document.getElementById('audioPlayback');
    audio.src = url;

    const a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_audio.webm';
    a.click();

    document.getElementById('status').textContent = "Recording saved!";
  };

  mediaRecorder.start();
  document.getElementById('status').textContent = "Recording...";
  document.getElementById('startBtn').disabled = true;
  document.getElementById('stopBtn').disabled = false;
};

document.getElementById('stopBtn').onclick = () => {
  mediaRecorder.stop();
  document.getElementById('stopBtn').disabled = true;
  document.getElementById('startBtn').disabled = false;
};
